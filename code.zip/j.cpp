#include<bits/stdc++.h>
using namespace std;

const int mx = 2e5*123;
int a[mx];
int preSum[mx];

int main()
{
    int n;
    cin>>n;

    char d;
    int sum = 0;
    for(int i=0; i<n; i++){
        cin>>d;
        int num = d - '0';
        sum+= num;
    }
    cout<<sum;

    return 0;
}
