#include<bits/stdc++.h>
using namespace std;

const int mx = 2e5*123;
int a[mx];

void fib(int n) {
    a[0] = 0, a[1] = 1;

    for (int i=2; i<=n; i++) {
        a[i] = a[i - 1] + a[i - 2];
    }
}

int main() {
    int n;
    cin >> n;

    fib(n);

    cout << a[n] << " ";


    return 0;
}
