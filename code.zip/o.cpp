#include<bits/stdc++.h>
using namespace std;

const int mx = 2e5*123;
int a[mx];

int main() {
    int n, m;
    cin >> n >> m;
    int frq[m+1] = {0};
    for (int i=0; i<n; i++) {
        cin >> a[i];
        frq[a[i]]++;
    }


    for (int i=1; i<=m; i++) {
        cout << frq[i] << endl;
    }

    return 0;
}
