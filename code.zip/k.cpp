#include<bits/stdc++.h>
using namespace std;

const int mx = 2e5*123;
int a[mx];
int preSum[mx];

int main()
{
    int m;
    cin>>m;

    for (int t = 0; t < m; t++) {
    int n;
    cin>>n;

    for (int i = 0; i < n; i++) {
      cin>>a[i];
    }

    for (int i = 0; i < n; i++) {
      int max = a[i];
      for (int j = i; j < n; j++) {
        if (a[j] > max) {
          max = a[j];
        }
        cout<<max<<" ";
      }
    }
  }

    return 0;
}
