#include<bits/stdc++.h>
using namespace std;

const int mx = 2e5*123;
int a[mx];
int preSum[mx];


int main()
{
    int n;
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>a[i];
    }

    int start = 0, end = n - 1;
    while (start < end) {
        swap(a[start], a[end]);
        start++;
        end--;
    }

    for(int i=0; i<n; i++){
        cout<<a[i]<<" ";
    }
    return 0;
}
