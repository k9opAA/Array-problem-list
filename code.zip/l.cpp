#include<bits/stdc++.h>
using namespace std;

const int mx = 2e5*123;
int a[mx];
int preSum[mx];

int main()
{
    int n;
    cin>>n;

    for (int i=0; i<n; i++) {
        cin>>a[i];
    }

    int minIndex = 0;
    int maxIndex = 0;
    int minVal = a[0];
    int maxVal = a[0];

    for (int i=1; i<n; i++) {
        if (a[i] < minVal) {
            minVal = a[i];
            minIndex = i;
        } else if (a[i] > maxVal) {
            maxVal = a[i];
            maxIndex = i;
        }
    }


    int temp = a[minIndex];
    a[minIndex] = a[maxIndex];
    a[maxIndex] = temp;

    for (int i = 0; i < n; i++) {
        cout<<a[i]<<" ";
    }

    return 0;
}
