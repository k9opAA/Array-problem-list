#include<bits/stdc++.h>
using namespace std;

const int mx = 2e5*123;
int a[mx];
int preSum[mx];

int main()
{
    int n;
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>a[i];
    }

    int minE = a[0];
    int f = 1;

    for(int i=1; i<n; i++){
        if(a[i]<minE){
            minE = a[i];
            f = 1;
        }
        else if(a[i]==minE){
            f++;
        }
    }

    if(f%2 == 1){
        cout<<"l";
    }
    else{
        cout<<"un";
    }

    return 0;
}
