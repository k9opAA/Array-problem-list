#include<bits/stdc++.h>
using namespace std;

const int mx = 2e5*123;
int a[mx];
int preSum[mx];

bool isPalindrome(int a[], int n) {
    int start = 0, end = n - 1;
    while (start < end) {
        if (a[start] != a[end]) {
            return false;
        }
        start++;
        end--;
    }
    return true;
}

int main()
{
    int n;
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>a[i];
    }

    if(isPalindrome(a, n)){
        cout<<"P";
    }
    else{
        cout<<"Not";
    }


    return 0;
}
