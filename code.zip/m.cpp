#include<bits/stdc++.h>
using namespace std;

const int mx = 2e5*123;
int a[mx];
int preSum[mx];

int main()
{
    int a, b;
    cin>>a>>b;
    char s[20];
    cin>>s;

    int i, v = 1;
    for (i = 0; i < a+b+1; i++) {
    if (i==a) {
      if (s[i] != '-') {
        v = 0;
        break;
      }
    } else if(s[i]<'0' || s[i]>'9'){
       {
        v = 0;
        break;
      }
    }
  }

  if (v) {
    cout<<"Yes";
  } else {
    cout<<"No";
  }

    return 0;
}
