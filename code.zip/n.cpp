#include<bits/stdc++.h>
using namespace std;

const int mx = 2e5*123;
int a[mx];
int preSum[mx];
int dp[10005];

int main() {
    int n;
    cin>>n;

    for (int i = 0; i < n; i++) {
        cin>>a[i];
    }

    int mOP = 0;
    int cOP = 0;
    int c = 1;

    while (c) {
        cOP++;

        for (int i = 0; i < n; i++) {
            if (a[i] % 2 != 0) {
                c = 0;
                break;
            }
        }

        if (c) {
            for (int i = 0; i < n; i++) {
                a[i] /= 2;
            }

            mOP = cOP;
        }
    }

    cout<<mOP;

    return 0;
}
